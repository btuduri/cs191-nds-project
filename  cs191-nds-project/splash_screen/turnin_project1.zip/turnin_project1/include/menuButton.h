#ifndef MENUBUTTON_H_
#define MENUBUTTON_H_

#include "basicObject.h"

class MenuButton : public basicObject{
	//void onClick();
};
#endif /*MENUBUTTON_H_*/
