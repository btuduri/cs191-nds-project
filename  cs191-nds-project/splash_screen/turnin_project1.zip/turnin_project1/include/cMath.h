#ifndef CMATH_H_
#define CMATH_H_

#include <math.h>

int gcd(int a, int b);


#endif /*CMATH_H_*/
