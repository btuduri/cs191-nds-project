#ifndef CSCREENTYPES_H_
#define CSCREENTYPES_H_

#define DEFAULT_SCREEN SplashScreen

#define SplashScreen 1
#define TitleMenuScreen 2
#define GamePlayScreen 3

#endif /*CSCREENTYPES_H_*/
