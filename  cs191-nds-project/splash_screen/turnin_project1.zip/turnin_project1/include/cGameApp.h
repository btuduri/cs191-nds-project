#ifndef CGAMEAPP_
#define CGAMEAPP_

#include "projectlib.h"


class cGameApp {
public:
	cGameApp(){};		//TODO: write this...
	~cGameApp() {}; 	//TODO: write this...
	
	void run();
	
private:
	
};

#endif
