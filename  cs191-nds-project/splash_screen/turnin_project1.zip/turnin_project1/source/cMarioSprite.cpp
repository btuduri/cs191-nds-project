#include "cMarioSprite.h"

cMarioSprite::cMarioSprite()
{
}

cMarioSprite::~cMarioSprite()
{
}

void cMarioSprite::updateSprite(int keys){
	
}
