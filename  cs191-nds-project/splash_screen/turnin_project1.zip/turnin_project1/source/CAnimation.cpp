#include "CAnimation.h"

CAnimation::CAnimation()
{
}

CAnimation::~CAnimation()
{
}
