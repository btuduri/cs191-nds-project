#include "cSprite.h"

cSprite::cSprite()
{
}

cSprite::~cSprite()
{
}
