

#include "projectlib.h"


// This is our main. See it in all its glory!!!!!
int main(void) {

	cGameApp game;
	game.run();
	
}
